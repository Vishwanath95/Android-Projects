package com.vishwanath.shortcut;

import android.app.Activity;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.util.Map;

public class MainActivity extends AppWidgetProvider {
    public static String LIST_ACTION="List_Action";
    static SharedPreferences sharedPreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String List = "ListKey";
    static Intent moveIntent;
    PendingIntent movePendingIntent;
    Activity activity ;
    static Map<String, ?> allEntries;
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager,
                         int[] appWidgetIds) {
        sharedPreferences = context.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        for (int i = 0; i < appWidgetIds.length; i++) {
            int currentWidgetId = appWidgetIds[i];Intent intent = new Intent(context, ListActivity.class);
            intent.setAction(LIST_ACTION);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.activity_main);
            views.setOnClickPendingIntent(R.id.layout_main, pendingIntent);
            appWidgetManager.updateAppWidget(currentWidgetId, views);
        }

    }
}