package com.vishwanath.shortcut;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vishwanath on 25/2/17.
 */
public class ShareActivity extends Activity{
    static Uri receivedUri;
    static File tempFile;
    Intent intent;
    String action, type;

    static List<String> listMap = new ArrayList<String>();

    static String[] shortcutList;
    static String[] shortcutList2 = new String[]{""};
    static int itr=0,count=0, cnt = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        try
        {
            intent = getIntent();
            action = intent.getAction();
            type = intent.getType();
            receivedUri = (Uri)intent.getParcelableExtra(Intent.EXTRA_STREAM);
            SharedPreferences.Editor editor = MainActivity.sharedPreferences.edit();
            if(MainActivity.sharedPreferences.getString(MainActivity.List,"").contains(receivedUri.toString())){
                Toast.makeText(ShareActivity.this, "File Already In The List", Toast.LENGTH_LONG).show();
                finish();
            }
            else {
                editor.putString(MainActivity.List, MainActivity.sharedPreferences.getString(MainActivity.List, "") + receivedUri.toString() + " ");
                editor.commit();
                finish();
            }

        }
        catch (Exception e)
        {
            Toast.makeText(getApplicationContext(), "Sorry! File Not Supported" + e.toString(), Toast.LENGTH_LONG).show();
            finish();
        }
        if (action == "List_Action")
        {
            Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_LONG).show();
        }
        if (Intent.ACTION_SEND.equals(action) && type != null)
        {
            if ("text/plain".equals(type))
            {
                handleSendText(intent); // Handle text being sent
            }
            else if (type.startsWith("image/"))
            {
                handleSendImage(intent); // Handle single image being sent
            }
        }
        else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type != null)
        {
            if (type.startsWith("image/"))
            {
                handleSendMultipleImages(intent); // Handle multiple images being sent
            }
        }
        else
        {
            // Handle other intents, such as being started from the home screen
        }
    }

    void handleSendText(Intent intent)
    {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText != null)
        {
            // Update UI to reflect text being shared
            //	TextView txtView = (TextView) findViewById(R.id.text_id);
            //	Toast.makeText(getApplicationContext(),sharedText, Toast.LENGTH_LONG).show();
            //	txtView.setText(sharedText);
        }
    }

    void handleSendImage(Intent intent)
    {
        Uri imageUri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
        if (imageUri != null)
        {
            // Update UI to reflect image being shared
        }
    }

    void handleSendMultipleImages(Intent intent)
    {
        ArrayList<Uri> imageUris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
        if (imageUris != null)
        {
            // Update UI to reflect multiple images being shared
        }
    }
}
