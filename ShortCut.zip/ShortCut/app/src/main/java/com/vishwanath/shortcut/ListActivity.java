package com.vishwanath.shortcut;

/**
 * Created by vishwanath on 25/2/17.
 */
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Toast;
import android.net.Uri;
import android.app.AlertDialog;
import java.io.File;
import android.os.Environment;
import java.util.*;
import android.content.Context;
import java.util.ArrayList;
import android.content.DialogInterface;
import android.app.PendingIntent;
import android.webkit.MimeTypeMap;
import android.view.View.*;
import android.content.SharedPreferences;

public class ListActivity extends Activity
{
    Context context;
    Uri viewUri;
    static File selectedFile;
    static Intent shareIntent, viewIntent;
    PendingIntent sharePendingIntent, viewPendingIntent;
    ArrayList seletedItems=new ArrayList();
    String[] folderList, fileName, temp;
    static int selected = -1, c = 0;
    static String check = "";
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        Bundle extras = getIntent().getExtras();
        Intent intent = getIntent();
        String string = getIntent().getAction();
        super.onCreate(savedInstanceState);
        MainActivity.sharedPreferences = getSharedPreferences(MainActivity.MyPREFERENCES, Context.MODE_PRIVATE);
        check = MainActivity.sharedPreferences.getString(MainActivity.List, null);
        switch (string)
        {
            case "List_Action":
                try
                {
                    if (check == null || check.equals(""))
                    {
                        Toast.makeText(ListActivity.this, "Please Add Shortcut to Access", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else
                        function();
                }
                catch (Exception e)
                {
                    Toast.makeText(ListActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
    public String getMimeType(String url)
    {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null)
        {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }

    public void function()
    {
        MainActivity.allEntries = MainActivity.sharedPreferences.getAll();
        ShareActivity.shortcutList = new String[MainActivity.allEntries.size()];
        for (Map.Entry<String, ?> entry : MainActivity.allEntries.entrySet())
        {
            ShareActivity.shortcutList2 = entry.getValue().toString().split(" ");
        }
        fileName = new String[ShareActivity.shortcutList2.length];
        temp = new String[ShareActivity.shortcutList2.length];
        for (int itr = 0; itr < ShareActivity.shortcutList2.length; itr++)
        {
            fileName = ShareActivity.shortcutList2[itr].split("/");
            temp[itr] = fileName[fileName.length - 1];
            temp[itr] = temp[itr].replaceAll("%20"," ");
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select File");
        builder.setCancelable(false);
        builder.setSingleChoiceItems(temp, -1, new

                DialogInterface.OnClickListener()

                {

                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        selected = which;
                        //	Toast.makeText(getApplicationContext(), "onclick", Toast.LENGTH_SHORT).show();
                    }

                })
                .setPositiveButton("OPEN", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id)
                    {
                        if (selected != -1)
                        {
                            finish();
                            viewIntent = new Intent();
                            viewIntent.setAction(Intent.ACTION_VIEW);
                            selectedFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString());
                            viewUri = Uri.parse(ShareActivity.shortcutList2[selected]);
                            viewIntent.setDataAndType(viewUri, getMimeType(ShareActivity.shortcutList2[selected]));
                            viewPendingIntent = PendingIntent.getActivity(ListActivity.this, 0, viewIntent, 0);
                            try
                            {
                                viewPendingIntent.send(getApplicationContext(), 0, viewIntent);
                            }
                            catch (Exception e)
                            {
                                Toast.makeText(ListActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                            }}
                        else
                        {
                            Toast.makeText(ListActivity.this, "Please Select Any File", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                })
                .setNeutralButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id)
                    {
                        finish();
                    }
                })
                .setNegativeButton("DELETE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id)
                    {
                        if (selected != -1)
                        {
                            String remove = ShareActivity.shortcutList2[selected];
                            String remove_quote = remove + " ";
                            if (MainActivity.sharedPreferences.getString(MainActivity.List, "").contains(remove))
                            {
                                String replace = MainActivity.sharedPreferences.getString(MainActivity.List, "");
                                String after_replace = replace.replace(remove_quote, "");
                                SharedPreferences.Editor editor = MainActivity.sharedPreferences.edit();
                                editor.putString(MainActivity.List, after_replace);
                                editor.commit();
                            }
                            finish();
                        }
                        else
                        {
                            Toast.makeText(ListActivity.this, "Please Select Any File", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}