package com.example.androidnotificationbar;

import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.io.InputStream;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.Button;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import android.graphics.*;
import java.net.*;
import android.app.Dialog;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class MainActivity extends Activity {
	Dialog dialog = null;
	static String[] folderString;
	static String mPath;
	PendingIntent viewPendingIntent = null;
	static File imageFile;
	Bitmap bitmap = null;
	Intent moveIntent;
	String sample_url = "http://codeversed.com/androidifysteve.png";
	Button btnAdd,buttonUp,btnOk,btnCancel;
	TextView textFolder,selectedFolder;
	static String[] itemsPass;
	static Integer key = new Integer(1);
	String KEY_TEXTPSS = "TEXTPSS";
    static final int CUSTOM_DIALOG_ID = 0;
    ListView dialog_ListView;

    File root;
    File curFolder;
	static Map<Integer,String> folderMap = new HashMap<Integer,String>();
    private List<String> fileList = new ArrayList<String>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// listener handler
	    View.OnClickListener handler = new View.OnClickListener(){
	        public void onClick(View v) {

	            switch (v.getId()) {

	                case R.id.btnShowNotification:
	                	takeScreenshot();
	                    break;

	                case R.id.btnCancelNotification:
	                	cancelNotification(0);
	                    break;

					case R.id.btnAdd:
	                	showDialog(CUSTOM_DIALOG_ID);
	                    break;
	            }
	        }
	    };

	    // we will set the listeners
	    findViewById(R.id.btnShowNotification).setOnClickListener(handler);
	    findViewById(R.id.btnCancelNotification).setOnClickListener(handler);
		findViewById(R.id.btnAdd).setOnClickListener(handler);
		root = new File(Environment.getExternalStorageDirectory().getAbsolutePath());
        curFolder = root;
	}

	public void takeScreenshot(){

		Date now = new Date();
        android.text.format.DateFormat.format("yyyy-MM-dd_hh:mm:ss", now);

        try {
            // image naming and path  to include sd card  appending name you choose for file
            mPath = Environment.getExternalStorageDirectory().toString() + "/PICTURES/Screenshots/" + now + ".jpg";

            // create bitmap screen capture
            View v1 = getWindow().getDecorView().getRootView();
            v1.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
            v1.setDrawingCacheEnabled(false);
            imageFile = new File(mPath);
            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.flush();
            outputStream.close();


            MediaScannerConnection.scanFile(this,
				new String[]{imageFile.toString()}, null,
				new MediaScannerConnection.OnScanCompletedListener() {
					public void onScanCompleted(String path, Uri uri) {
						Log.i("ExternalStorage", "Scanned " + path + ":");
						Log.i("ExternalStorage", "-> uri=" + uri);
					}
				});

			// openScreenshot(imageFile);

			Intent viewIntent = new Intent();
			viewIntent.setAction(Intent.ACTION_VIEW);
			Uri uri = Uri.fromFile(imageFile);
			viewIntent.setDataAndType(uri, "image/*");
			viewPendingIntent = PendingIntent.getActivity(MainActivity.this, 0, viewIntent, 0);
        } catch (Throwable e) {
            // Several error may come out with file handling or OOM
            e.printStackTrace();
        }

		// define sound URI, the sound to be played when there's a notification
		Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

		// intent triggered, you can add other intent for other actions
		Intent intent = new Intent(MainActivity.this, NotificationReceiver.class);
		PendingIntent pIntent = PendingIntent.getActivity(MainActivity.this, 0, intent, 0);
		Intent shareIntent = new Intent(Intent.ACTION_SEND);
        // If you want to share a png image only, you can do:
        // setType("image/png"); OR for jpeg: setType("image/jpeg");
        shareIntent.setType("image/*");

        // Make sure you put example png image named myImage.png in your
        // directory
        /*String imagePath = Environment.getExternalStorageDirectory()
		 + "/myImage.png";*/

        File imageFileToShare = new File(mPath);

        Uri uri = Uri.fromFile(imageFileToShare);
        shareIntent.putExtra(Intent.EXTRA_STREAM, uri);

		PendingIntent pendingShareIntent = PendingIntent.getActivity(MainActivity.this, 0, Intent.createChooser(shareIntent, "share..."),
																	 PendingIntent.FLAG_UPDATE_CURRENT);
		// this is it, we'll build the notification!
		// in the addAction method, if you don't want any icon, just set the first param to 0
		try{
			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inPreferredConfig = Bitmap.Config.ARGB_8888;
			bitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options);
			}
		catch(Exception e){
			e.printStackTrace();
		}
		
	
		moveIntent = new Intent(MainActivity.this, NotificationReceiver.class);
		PendingIntent movePendingIntent = PendingIntent.getActivity(MainActivity.this, 0, moveIntent, 0);
		Notification mNotification = new Notification.Builder(this)

			.setContentTitle("Screenshot Taken")
			//	.setContentText("Here's an awesome update for you!")
			.setSmallIcon(R.drawable.ninja)
			.setLargeIcon(bitmap)
			.setStyle(new Notification.BigPictureStyle()
			.bigPicture(bitmap))
			.setContentIntent(viewPendingIntent)
			.setSound(soundUri)

			.addAction(0, "Move", movePendingIntent)
			.addAction(0, "Delete", viewPendingIntent)
			.addAction(0, "Share",pendingShareIntent)

			.build();

		NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

		// If you want to hide the notification after it was selected, do the code below
		// myNotification.flags |= Notification.FLAG_AUTO_CANCEL;

		notificationManager.notify(0, mNotification);


	}
	/*private void openScreenshot(File imageFile) {
	 Intent intent = new Intent();
	 intent.setAction(Intent.ACTION_VIEW);
	 Uri uri = Uri.fromFile(imageFile);
	 intent.setDataAndType(uri, "image/*");
	 startActivity(intent);
	 }*/

	public void cancelNotification(int notificationId){



		File delFile = new File(imageFile,mPath);
		delFile.delete();

		if (Context.NOTIFICATION_SERVICE!=null) {
            String ns = Context.NOTIFICATION_SERVICE;
            NotificationManager nMgr = (NotificationManager) getApplicationContext().getSystemService(ns);
            nMgr.cancel(notificationId);
        }
	}


    @Override
    protected Dialog onCreateDialog(int id) {

        

        switch (id) {
            case CUSTOM_DIALOG_ID:
                dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.dialoglayout);
                dialog.setTitle("Select Folder");
                dialog.setCancelable(true);
                dialog.setCanceledOnTouchOutside(true);

                textFolder = (TextView) dialog.findViewById(R.id.folder);
				selectedFolder = (TextView) findViewById(R.id.selectedFolder);
                buttonUp = (Button) dialog.findViewById(R.id.up);
                buttonUp.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							ListDir(curFolder.getParentFile());
						}
					});
				btnOk = (Button)dialog.findViewById(R.id.btnOk);
				/*btnOk.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v){
						//	selectedFolder.setVisibility(TextView.VISIBLE);
							folderString = textFolder.getText().toString().split("/");
							selectedFolder.setText(folderString[folderString.length -1]);
							folderMap.put(key,folderString[folderString.length -1]);
							key++;
							dialog.dismiss();
							selectedFolder.setVisibility(TextView.VISIBLE);
							}
					});*/
				btnCancel = (Button)dialog.findViewById(R.id.btnCancel);
				btnCancel.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v){
							dialog.dismiss();
						}
					});
                dialog_ListView = (ListView) dialog.findViewById(R.id.dialoglist);
                dialog_ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
							File selected = new File(fileList.get(position));
							if(selected.isDirectory()) {
								ListDir(selected);
							} else {
								Toast.makeText(MainActivity.this, selected.toString() + " selected",
											   Toast.LENGTH_LONG).show();
								dismissDialog(CUSTOM_DIALOG_ID);
							}
						}
					});

                break;
        }
        return dialog;
    }

    @Override
    protected void onPrepareDialog(int id, Dialog dialog) {
        super.onPrepareDialog(id, dialog);
        switch (id) {
            case CUSTOM_DIALOG_ID:
                ListDir(curFolder);
                break;
        }
    }

    void ListDir(File f) {
        if(f.equals(root)) {
            buttonUp.setEnabled(false);
        } else {
            buttonUp.setEnabled(true);
        }

        curFolder = f;
        textFolder.setText(f.getPath());
		btnOk.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v){
					//	selectedFolder.setVisibility(TextView.VISIBLE);
					folderString = textFolder.getText().toString().split("/");
					selectedFolder.setText(folderString[folderString.length -1]);
					folderMap.put(key,folderString[folderString.length -1]);
					key++;
					dialog.dismiss();
					selectedFolder.setVisibility(TextView.VISIBLE);
				}
			});
	
        File[] files = f.listFiles();
        fileList.clear();

        for(File file : files) {
            fileList.add(file.getPath());
        }

        ArrayAdapter<String> directoryList = new ArrayAdapter<String>(this,
																	  android.R.layout.simple_list_item_1, fileList);
        dialog_ListView.setAdapter(directoryList);
    }
	/*	private void shareImage() {
	 Intent share = new Intent(Intent.ACTION_SEND);

	 // If you want to share a png image only, you can do:
	 // setType("image/png"); OR for jpeg: setType("image/jpeg");
	 share.setType("image/*");

	 // Make sure you put example png image named myImage.png in your
	 // directory
	 String imagePath = Environment.getExternalStorageDirectory()
	 + "/myImage.png";

	 File imageFileToShare = new File(imagePath);

	 Uri uri = Uri.fromFile(imageFileToShare);
	 share.putExtra(Intent.EXTRA_STREAM, uri);

	 startActivity(Intent.createChooser(share, "Share Image!"));
	 }*/

}
