package com.example.androidnotificationbar;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.app.PendingIntent;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;
import com.example.androidnotificationbar.MainActivity;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.os.Environment;
import android.util.Log;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.io.*;
import org.apache.http.entity.*;
import java.util.*;
import org.apache.http.impl.execchain.*;

public class NotificationReceiver extends Activity {
	String sdCard = Environment.getExternalStorageDirectory().getAbsolutePath().toString();
	private static final String TAG = "MainActivity.java";
	Map<Integer,String> dataMap = new HashMap<Integer,String>();
	@Override
	public void onCreate(Bundle savedInstanceState)  {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_temp);
		String[] str = new String[MainActivity.folderMap.size()];
		dataMap = MainActivity.folderMap;
			for(int itr =0; itr < dataMap.size() ;itr++){  
				str[itr] = dataMap.get(itr+1);  }
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Select Folder To Move");
        builder.setItems(str, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int item) {
					// Do something with the selection
						moveFile(MainActivity.imageFile.getAbsolutePath(),sdCard+"/"+dataMap.get(item+1)+"/"+MainActivity.imageFile.getName());
				}
			});
        AlertDialog alert = builder.create();
        alert.show();
		}
		public void moveFile(String sL, String tL){
		
			Toast.makeText(getApplicationContext(),tL,Toast.LENGTH_SHORT).show();
        // the file to be moved or copied
        File sourceLocation = new File (sL);

        // make sure your target location folder exists!
        File targetLocation = new File (tL);
        // just to take note of the location sources
        Log.v(TAG, "sourceLocation: " + sourceLocation);
        Log.v(TAG, "targetLocation: " + targetLocation);

        try {

            // 1 = move the file, 2 = copy the file
            int actionChoice = 1;

            // moving the file to another directory
            if(actionChoice==1){

                if(sourceLocation.renameTo(targetLocation)){
					Toast.makeText(getApplicationContext(),"Move File Successful",Toast.LENGTH_SHORT).show();  
                }else{
                    Toast.makeText(getApplicationContext(),"Move File Failed",Toast.LENGTH_SHORT).show();  
                }

            }

            // we will copy the file
            else{

                // make sure the target file exists

                if(sourceLocation.exists()){

                    InputStream in = new FileInputStream(sourceLocation);
                    OutputStream out = new FileOutputStream(targetLocation);

                    // Copy the bits from instream to outstream
                    byte[] buf = new byte[1024];
                    int len;

                    while ((len = in.read(buf)) > 0) {
                        out.write(buf, 0, len);
                    }

                    in.close();
                    out.close();

                    Toast.makeText(getApplicationContext(),"Copy File Successful",Toast.LENGTH_SHORT).show(); 
					//sourceLocation.delete();

                }else{
                    Toast.makeText(getApplicationContext(),"Copy File Failed",Toast.LENGTH_SHORT).show(); 
                }

            }

        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
